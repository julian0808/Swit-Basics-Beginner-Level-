import Foundation

// "There is always a value and its a Boolean"
let myBool: Bool? = false

//"We dont know if there is a value, but if there is, it is a Boolean"
var myOtherBool: Bool? = nil


//print(myOtherBool ?? default value)
//myOtherBool = true
//print(myOtherBool)
//myOtherBool = false
//print(myOtherBool)
//myOtherBool = nil
//print(myOtherBool)

// nill coalescing operator

// example 1

let newValue: Bool? = myOtherBool

// "The value of myotherBool (if there is one), otherwise false"
let newValue2: Bool = myOtherBool ?? false

print("New value 2: \(newValue2.description)")

var myString: String? = "Hello, world!"

print(myString ?? "There is no value!")

myString = "New text!"
print(myString ?? "There is no value!")

myString = nil

print(myString ?? "There is no value!")

//let newString = myString ?? "some default value"

// -------------------------------------------------------

// Example 2:

var userIsPremium: Bool? = nil

func checkIfUserIsPremium() -> Bool? {
    return userIsPremium
}
func checkIfUserIsPremium2() -> Bool {
    return userIsPremium ?? false
}

let isPremium = checkIfUserIsPremium2()

// if let
// When if-let is successfull, enter the closure
func checkIfUserIsPremium3() -> Bool {
    
    // If there is a value, let newvValue equal that value
    if let newValue = userIsPremium {
        // Here we have access to the non-optional value
        return newValue
    } else {
        return false
    }
}

func checkIfUserIsPremium4() -> Bool {
    if let newValue = userIsPremium {
        return newValue
    }
    
    return false
}
func checkIfUserIsPremium5() -> Bool {
    if let userIsPremium {
        return userIsPremium
    }
    
    return false
}

// Guard
// When a guard is failure, enter the closure
func checkIfUserIsPremium6() -> Bool {
    
    // Make sure there is a value
    // If there is, let newValue equal that value
    // Else (otherwise) return out of the function
    guard let newValue = userIsPremium else {
        return false
    }
    
    // Here we have access to the non-optional value
    return newValue
}

func checkIfUserIsPremium7() -> Bool {
    guard let userIsPremium else {
        return false
    }
    
    return userIsPremium
}

// -------------------------------------------------------

var userIsNew: Bool? = true
var userDidCompleteOnboarding: Bool? = false
var userFavoriteMovie: String? = nil


func checkIfUserIsSetUp() -> Bool {
    
    if let userIsNew, let userDidCompleteOnboarding, let userFavoriteMovie {
        // userIsNew == Bool AND
        // userDidCompleteOnboarding == Bool AND
        // userFavoriteMovie == String
        return getUserStatus(userIsNew: userIsNew, userDidCompleteOnboarding: userDidCompleteOnboarding, userFavoriteMovie: userFavoriteMovie)
    } else {
        // user == nil oR
        // userDidComplteOnboarding == nil OR
        // userFavoriteMovie == nil
        return false
    }
}

func checkIfUserIsSetUp2() -> Bool {
    
    guard let userIsNew, let userDidCompleteOnboarding, let userFavoriteMovie else {
        // user == nil oR
        // userDidComplteOnboarding == nil OR
        // userFavoriteMovie == nil
        
        return false
    }
    
    
    
    // userIsNew == Bool AND
    // userDidCompleteOnboarding == Bool AND
    // userFavoriteMovie == String
    return getUserStatus(userIsNew: userIsNew, userDidCompleteOnboarding: userDidCompleteOnboarding, userFavoriteMovie: userFavoriteMovie)
}


func getUserStatus(userIsNew: Bool, userDidCompleteOnboarding : Bool, userFavoriteMovie: String) -> Bool {
    if userIsNew && userDidCompleteOnboarding {
        return true
    }
    
    return false
}


// layered if-let
func checkIfUserIsSetUp3() -> Bool {
    if let userIsNew {
        // userIsNew == Bool
        
        if let userDidCompleteOnboarding {
            // userDidCompleteOnboarding == Bool
            
            if let userFavoriteMovie {
                // userFavoriteMovie == String
                return getUserStatus(userIsNew: userIsNew, userDidCompleteOnboarding: userDidCompleteOnboarding, userFavoriteMovie: userFavoriteMovie)

            } else {
                // userFavoriteMovie == nil
                return false
            }
            
        } else {
            // userDidComplteOnboarding == nil
            return false            
        }
        
    } else {
        // user == nil
        return false

    }
    
}



// layered guard
func checkIfUserIsSetUp4() -> Bool {
    guard let userIsNew else {
        // user == nil
        return false
    }

    // userIsNew == Bool
    
    guard let userDidCompleteOnboarding else {
        // userDidComplteOnboarding == nil
        return false
    }
    // userDidCompleteOnboarding == Bool
    
    guard let userFavoriteMovie else {
        // userFavoriteMovie == nil
        return false
    }
    // userFavoriteMovie == String
    
    return getUserStatus(userIsNew: userIsNew, userDidCompleteOnboarding: userDidCompleteOnboarding, userFavoriteMovie: userFavoriteMovie)
}


// Optional chaining

func getUserName() -> String? {
    return "test"
}

func getTitle() -> String {
    return "title"
}

func getUserData() {
    
    // "I will get the count if the username is not nil "
    let username: String? = getUserName()
    let count: Int? = username?.count
    
    let title: String = getTitle()
    
    // "I will get the count always"
    let count2 = title.count
    
    
    // If user name has a value, and the first character in username has a value, then return the value of isLowerCase
    // Optional chaining
    let firstCharacterIsLowerCase = (username?.first?.isLowercase) ?? false
    
    
    // "I will get the count because I know 100% that user is not nil"
    // This will crash your application if username is nil!
    let count3: Int = username!.count
    
}

// - Safely unwrap an optional
// nil coalcing
// if-let
// guard

// expliictly unwrap optional











