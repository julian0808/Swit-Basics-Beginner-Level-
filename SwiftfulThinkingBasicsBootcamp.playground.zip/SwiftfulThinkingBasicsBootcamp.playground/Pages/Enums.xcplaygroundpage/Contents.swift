import Foundation


// Enum is the same as Struct except we know at cases at runtime

struct cardModel {
    let brand: cardBrandOpiton
    let model: String
}

struct CarBrand {
    let title : String
}


// Enums are stored in memory the same say as a Struct but we cannot mutate  them
enum cardBrandOpiton {
    case ford, toyota, honda
    
    var title: String {
        switch self {
        case .ford:
            return "Ford"
        case .toyota:
            return "Totoya"
        case .honda:
            return "Honda"
//        default:
//            return "Default"
        }
        
    }
}

//var car1: cardModel = cardModel(brand: "Ford", model: "Fiesta")
//var car2: cardModel = cardModel(brand: "Ford", model: "Focus")
//var car3: cardModel = cardModel(brand: "Toyota", model: "Camry")

//var brand1 = <#T##CarBrand#>(title: "Ford")
//var brand2 = <#T##CarBrand#>(title: "Toyota")
//
//var car1 = cardModel(brand: brand1, model: "Fiesta")
//var car2 = cardModel(brand: brand1 model: "Focus")
//var car3 = cardModel(brand: brand2 model: "Camry")

var car1 = cardModel(brand: .ford, model: "Fiesta")
var car2 = cardModel(brand: .ford, model: "Focus")
var car3 = cardModel(brand: .toyota, model: "Camry")

var forBrand: cardBrandOpiton = .ford

print(forBrand.title)

