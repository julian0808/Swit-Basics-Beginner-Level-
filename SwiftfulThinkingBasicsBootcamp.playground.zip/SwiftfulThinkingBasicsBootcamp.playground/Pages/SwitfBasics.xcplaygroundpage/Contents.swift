import Foundation

var greeting = "Hello, playground"


print(greeting)
print(greeting)
print(greeting)
print(greeting)
print(greeting)
print(greeting)

// This is a single_single comment

// multi line comment
/*
 This is a multi-line comment
 that goes to
 multiple lnes!
 */

// Naming Conversionts

// Camel Case - CORRECT!
// The first word is lowercased and the the first character in every following word is uppercase.

let firstGreeting = "Hello, world!"
let thisIsMyFirstGreeting = "Hello, world!"

let thisismysecondgreeting = "Hello, world!"

// Snake Case - wrong
let this_is_what_snake_case_looks_like = "Hello, world!"

// Pascal Case - Wrong
let ThisIsWhatPascalCaseLookLike = "Hello, world!"

// Camel Case - right
let thisIsWhatCameCaseLooksLike = "Hello, world!"



