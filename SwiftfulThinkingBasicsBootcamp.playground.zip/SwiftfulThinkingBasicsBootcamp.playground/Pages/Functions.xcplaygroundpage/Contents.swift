import Foundation

//var myItem: Bool = false
//
//myItem = true
//
//print(myItem)


func myFirstFunction() {
    print("MY FIRST FUNCTION CALLED")
    mySecondFunction()
    myThirdFunction()
}

func mySecondFunction() {
    print("MY SECOND FUNCTION CALLED")
    
}

func myThirdFunction() {
    print("MY THIRD FUNCTION CALLED")
}

myFirstFunction()

// Example 1

func getUseraName() -> String {
    let username = "Nick"
    return username
}

func checkIfUserIsPremium() -> Bool {
    return false
}

let name: String = getUseraName()

// -------------------------------------------------------


// Example 2

showFirstScreen()

func showFirstScreen() {
    var userDidCompleteOnboarding: Bool = false
    var userProfileIsCreated: Bool = true
    let status = checkUserStatus(DidCompleteOnboarding: userDidCompleteOnboarding, profileIsCreated: userProfileIsCreated)
    
    if status == true {
        print("SHOW HOME SCREEN")
    }else {
        print("SHOW ONBOARDING SCREEN")
    }
}

func checkUserStatus(DidCompleteOnboarding: Bool, profileIsCreated: Bool) -> Bool {
    if DidCompleteOnboarding && profileIsCreated {
        doSomethingElse(someValue: DidCompleteOnboarding)
        return true
    }else {
      return false
    }
}

func doSomethingElse(someValue: Bool) {
    
}

// -------------------------------------------------------

// Example 3

let newValue = doSomething()

func doSomething() -> String {
    var title: String = "Avengers"
    
    // "If title is equal to Avengers"
    if title == "Avengers" {
        return "Marvel"
    } else {
        return "Not Marvel"
    }
    
}

checkIfTitleIsAvengers()


func checkIfTitleIsAvengers() -> Bool  {
    var title: String = "Avengers"
    
    // "Make sure title == Avengers
    guard title == "Avengers" else {
        return false
    }
    
    return true
}

func checkIfTitleIsAvengers2() -> Bool  {
    var title: String = "Avengers"
    
    if title == "Avengers" {
        return true
    } else {
        return false
    }
}

// Calculated variables are basically functions
// Generally good for when you don't need to pass data into the function

let number1 = 5
let number2 = 8

func calculatedNumbers() -> Int {
    return number1 + number2
}

func calculatedNumbers (value1: Int, value2: Int) -> Int {
    return value1 + value2
}

let result1 = calculatedNumbers()
let result2 = calculatedNumbers(value1: number1, value2: number2)

var caculatedNumber: Int {
    return number1 + number2
}



